package com.jangphong.hem.karbicalender2;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TableLayout;
import android.widget.TextView;

import java.util.Calendar;

public class Frag7 extends Fragment
{
    TableLayout tabletxt;

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Calendar cal = Calendar.getInstance();
        if(cal.get(Calendar.MONTH)==Calendar.JULY)
        {
            if (cal.get(Calendar.DATE) == 1) {
                TextView t1 = (TextView) getView().findViewById(R.id.day1);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 2) {
                TextView t1 = (TextView) getView().findViewById(R.id.day2);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 3) {
                TextView t1 = (TextView) getView().findViewById(R.id.day3);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 4) {
                TextView t1 = (TextView) getView().findViewById(R.id.day4);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 5) {
                TextView t1 = (TextView) getView().findViewById(R.id.day5);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 6) {
                TextView t1 = (TextView) getView().findViewById(R.id.day6);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 7) {
                TextView t1 = (TextView) getView().findViewById(R.id.day7);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 8) {
                TextView t1 = (TextView) getView().findViewById(R.id.day8);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 9) {
                TextView t1 = (TextView) getView().findViewById(R.id.day9);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 10) {
                TextView t1 = (TextView) getView().findViewById(R.id.day10);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 11) {
                TextView t1 = (TextView) getView().findViewById(R.id.day11);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 12) {
                TextView t1 = (TextView) getView().findViewById(R.id.day12);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 13) {
                TextView t1 = (TextView) getView().findViewById(R.id.day13);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 14) {
                TextView t1 = (TextView) getView().findViewById(R.id.day14);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 15) {
                TextView t1 = (TextView) getView().findViewById(R.id.day15);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 16) {
                TextView t1 = (TextView) getView().findViewById(R.id.day16);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 17) {
                TextView t1 = (TextView) getView().findViewById(R.id.day17);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 18) {
                TextView t1 = (TextView) getView().findViewById(R.id.day18);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 19) {
                TextView t1 = (TextView) getView().findViewById(R.id.day19);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 20) {
                TextView t1 = (TextView) getView().findViewById(R.id.day20);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 21) {
                TextView t1 = (TextView) getView().findViewById(R.id.day21);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 22) {
                TextView t1 = (TextView) getView().findViewById(R.id.day22);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 23) {
                TextView t1 = (TextView) getView().findViewById(R.id.day23);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 24) {
                TextView t1 = (TextView) getView().findViewById(R.id.day24);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 25) {
                TextView t1 = (TextView) getView().findViewById(R.id.day25);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 26) {
                TextView t1 = (TextView) getView().findViewById(R.id.day26);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 27) {
                TextView t1 = (TextView) getView().findViewById(R.id.day27);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 28) {
                TextView t1 = (TextView) getView().findViewById(R.id.day28);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 29) {
                TextView t1 = (TextView) getView().findViewById(R.id.day29);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
            else if (cal.get(Calendar.DATE) == 30) {
                TextView t1 = (TextView) getView().findViewById(R.id.day30);
                t1.setBackgroundResource(R.drawable.cell_shape);
            }
        }
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.frag7, container, false);

        //tofindviewby id, defining inflater is necessary in onCreateView



        return v;
    }

    public static Frag7 newInstance(String text) {

        Frag7 f = new Frag7();
        Bundle b = new Bundle();
        b.putString("msg", text);

        f.setArguments(b);

        return f;
    }
}
