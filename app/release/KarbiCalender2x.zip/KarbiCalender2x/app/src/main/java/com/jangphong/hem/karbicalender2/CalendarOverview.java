package com.jangphong.hem.karbicalender2;

import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;


public class CalendarOverview extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar_overview);

       FragmentManager manager = getSupportFragmentManager();

        Frag1 janFrag = new Frag1();
        manager.beginTransaction()
                .replace(R.id.janView,janFrag,janFrag.getTag())
                .commit();



        Frag2 febFrag = new Frag2();
        manager.beginTransaction()
                .replace(R.id.febView,febFrag,febFrag.getTag())
                .commit();

       Frag3 marchFrag = new Frag3();
        manager.beginTransaction()
                .replace(R.id.marchView,marchFrag,marchFrag.getTag())
                .commit();


        Frag4 aprilFrag = new Frag4();
        manager.beginTransaction()
                .replace(R.id.aprilView,aprilFrag,aprilFrag.getTag())
                .commit();

        Frag5 mayFrag = new Frag5();
        manager.beginTransaction()
                .replace(R.id.mayView,mayFrag,mayFrag.getTag())
                .commit();

        Frag6 juneFrag = new Frag6();
        manager.beginTransaction()
                .replace(R.id.juneView,juneFrag,juneFrag.getTag())
                .commit();

        Frag7 julyFrag = new Frag7();
        manager.beginTransaction()
                .replace(R.id.julyView,julyFrag,julyFrag.getTag())
                .commit();

        Frag8 augFrag = new Frag8();
        manager.beginTransaction()
                .replace(R.id.augView,augFrag,augFrag.getTag())
                .commit();

        Frag9 sepFrag = new Frag9();
        manager.beginTransaction()
                .replace(R.id.sepView,sepFrag,sepFrag.getTag())
                .commit();

        Frag10 octFrag = new Frag10();
        manager.beginTransaction()
                .replace(R.id.octView,octFrag,octFrag.getTag())
                .commit();

        Frag11 novFrag = new Frag11();
        manager.beginTransaction()
                .replace(R.id.novView,novFrag,novFrag.getTag())
                .commit();

        Frag12 decFrag = new Frag12();
        manager.beginTransaction()
                .replace(R.id.decView,decFrag,decFrag.getTag())
                .commit();
    }
}
